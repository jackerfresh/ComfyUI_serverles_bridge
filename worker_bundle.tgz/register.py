"""Ждёт URL из лога cloudflared и регистрируется в локальной панели."""

import json
import subprocess
import os
import re
import sys
import time
import urllib.request

TUNNEL_RE = re.compile(r"https://[a-z0-9][a-z0-9.-]*\.trycloudflare\.com")
REG = "/workspace/register.json"


def _read_cfg() -> dict:
    for _ in range(600):
        if os.path.exists(REG):
            try:
                with open(REG, "r", encoding="utf-8") as f:
                    return json.load(f)
            except json.JSONDecodeError:
                pass
        time.sleep(1)
    return {}


def _find_url() -> str:
    path = "/workspace/tunnel.log"
    for _ in range(120):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                url = None
                for line in f:
                    m = TUNNEL_RE.search(line)
                    if m:
                        url = m.group(0)
            if url:
                return url
        except OSError:
            pass
        time.sleep(3)
    return ""




def _public_ip() -> str:
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip"):
        try:
            out = subprocess.run(["curl", "-s", "--max-time", "8", url],
                                 capture_output=True, text=True, timeout=15)
            ip = (out.stdout or "").strip()
            if ip and ip.count(".") == 3:
                return ip
        except Exception:  # noqa: BLE001
            continue
    return ""


def main() -> int:
    cfg = _read_cfg()
    register_url = cfg.get("register_url") or ""
    token = cfg.get("token") or ""
    secret = cfg.get("secret") or ""
    if not register_url:
        print("нет register_url — регистрация невозможна")
        return 1
    # 1) прямой IP:8000 (быстро, без Cloudflare)
    url = ""
    ip = _public_ip()
    if ip:
        direct = f"http://{ip}:8000"
        try:
            ok = subprocess.run(["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
                                 "--max-time", "8", direct + "/health"],
                                capture_output=True, text=True, timeout=15)
            if (ok.stdout or "").strip() == "200":
                url = direct
                print("direct:", url)
        except Exception:  # noqa: BLE001
            pass
    if not url:
        url = _find_url()
    if not url:
        print("не нашёл URL туннеля")
        return 1
    print("tunnel:", url)
    body = json.dumps({"url": url, "token": token, "secret": secret,
                       "gpus": ["vast"], "workers": 1}).encode()
    for attempt in range(40):
        try:
            req = urllib.request.Request(register_url, data=body,
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=20) as r:
                print("register:", r.status, r.read()[:200])
                if r.status == 200:
                    return 0
        except Exception as e:  # noqa: BLE001
            print("register err:", e)
        time.sleep(10)
    return 1


if __name__ == "__main__":
    sys.exit(main())
