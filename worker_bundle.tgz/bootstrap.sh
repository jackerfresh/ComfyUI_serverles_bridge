#!/bin/bash
# Bootstrap воркера ComfyUI на Vast.ai: модели качаются ПАРАЛЛЕЛЬНО с установкой
# ComfyUI, чтобы старт укладывался в ~5 минут.
set -x
cd /workspace
command -v curl >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq curl git >/dev/null 2>&1)
command -v git  >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq git >/dev/null 2>&1)
PY=$(command -v python3 || command -v python)
if [ -z "$PY" ]; then echo "[bootstrap] python not found"; exit 1; fi
PROG=$($PY -c "import json;print(json.load(open('/workspace/register.json')).get('progress_url',''))" 2>/dev/null)
ping() { curl -s -o /dev/null --max-time 10 -X POST "$PROG" -H "Content-Type: application/json" -d "{\"step\":\"$1\"}" || true; }
echo "[bootstrap] python=$PY progress=$PROG"

# 1) модели — в фоне
cd /workspace || exit 1
ping "models-start"
( $PY fetch_models.py > /workspace/models.log 2>&1; ping "models-done" ) &
MODELS_PID=$!

# 2) ComfyUI: клонируем только если нет в образе
if [ ! -f /workspace/comfy/main.py ]; then
  ping "comfy-clone"
  git clone --depth 1 https://github.com/comfyanonymous/ComfyUI.git /workspace/comfy
fi
cd /workspace/comfy || exit 1
ping "torch"
$PY -c "import torch" 2>/dev/null || $PY -m pip install -q --no-compile --index-url https://download.pytorch.org/whl/cu121 torch
ping "deps"
$PY -m pip install -q -r requirements.txt

# 3) ноды
cd /workspace || exit 1
ping "nodes-start"
$PY install_nodes.py || true

# 4) ждём модели
ping "models-wait"
wait $MODELS_PID || true
tail -c 800 /workspace/models.log 2>/dev/null || true

# 5) ComfyUI + bridge
cd /workspace/comfy || exit 1
ping "comfy-start"
nohup $PY main.py --listen 127.0.0.1 --port 8188 \
  --preview-method none --disable-smart-memory \
  > /workspace/comfy.log 2>&1 &
cd /workspace || exit 1
ping "bridge-start"
nohup $PY bridge_server.py > /workspace/bridge.log 2>&1 &
sleep 2

# 6) туннель + регистрация
if [ ! -x /workspace/cloudflared ]; then
  curl -sL -o /workspace/cloudflared \
    https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64
  chmod +x /workspace/cloudflared
fi
nohup /workspace/cloudflared tunnel --url http://127.0.0.1:8000 \
  --no-autoupdate > /workspace/tunnel.log 2>&1 &
ping "register-start"
$PY register.py || echo "[bootstrap] register failed"
# контейнер не должен умирать: держим его живым
exec tail -f /dev/null
