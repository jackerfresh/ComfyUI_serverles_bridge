"""Ставит кастомные ноды на Vast-воркере по nodes.json (repo + classes)."""

import json
import os
import subprocess
import sys

COMFY = "/workspace/comfy"
CUSTOM = os.path.join(COMFY, "custom_nodes")


def _run(cmd: list, cwd: str | None = None) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=900)
        return p.returncode, (p.stdout + p.stderr)[-2000:]
    except Exception as e:  # noqa: BLE001
        return 1, str(e)


def _install(repo: str) -> str:
    name = repo.rstrip("/").split("/")[-1]
    if name.endswith(".git"):
        name = name[:-4]
    dest = os.path.join(CUSTOM, name)
    if os.path.isdir(os.path.join(dest, ".git")):
        return f"ok {name}: уже есть"
    code, out = _run(["git", "clone", "--depth", "1", repo, dest])
    if code != 0:
        return f"ERR clone {name}: {out[-300:]}"
    req = os.path.join(dest, "requirements.txt")
    if os.path.exists(req):
        _run([sys.executable, "-m", "pip", "install", "-q", "-r", req])
    return f"ok {name}"


def main() -> int:
    path = "/workspace/nodes.json"
    if not os.path.exists(path):
        print("нет nodes.json — пропускаю")
        return 0
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    repos = [r.get("repo") for r in (data.get("packs") or []) if r.get("repo")]
    if not repos:
        print("нод в манифесте нет")
        return 0
    os.makedirs(CUSTOM, exist_ok=True)
    print(f"пакетов нод: {len(repos)}")
    for repo in repos:
        print(_install(repo))
    return 0


if __name__ == "__main__":
    sys.exit(main())
