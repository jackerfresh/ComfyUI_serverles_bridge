"""Минимальный bridge-сервер для Vast-воркера.

Повторяет протокол kaggle-сервера (его ждёт наш локальный клиент):
  GET  /health                      — статус
  POST /submit {prompt}             — поставить workflow
  GET  /job/{id}?since=N            — статус/события
  GET  /file?type&subfolder&filename — отдать файл результата
  POST /interrupt                   — прервать
  POST /shutdown                    — погасить

ComfyUI должен быть запущен на 127.0.0.1:8188.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
import uuid

import aiohttp
from aiohttp import web

TOKEN = (os.environ.get("VAST_BRIDGE_TOKEN") or "").strip()
COMFY = os.environ.get("VAST_COMFY_URL", "http://127.0.0.1:8188")
PORT = int(os.environ.get("VAST_BRIDGE_PORT", "8000"))
OUT_DIR = os.environ.get("VAST_OUT_DIR", "/workspace/comfy/output")

JOBS: dict[str, dict] = {}


def _auth(request: web.Request) -> bool:
    if not TOKEN:
        return True
    got = (request.headers.get("Authorization") or "").replace("Bearer ", "").strip()
    return got == TOKEN


def _j(data: dict, status: int = 200) -> web.Response:
    return web.json_response(data, status=status, dumps=lambda d: json.dumps(d, ensure_ascii=False))


async def _comfy_prompt(session: aiohttp.ClientSession, prompt: dict) -> str:
    client_id = uuid.uuid4().hex
    async with session.post(f"{COMFY}/prompt",
                            json={"prompt": prompt, "client_id": client_id},
                            timeout=aiohttp.ClientTimeout(total=60)) as r:
        data = await r.json()
        if r.status >= 400:
            raise RuntimeError(json.dumps(data)[:400])
        return data["prompt_id"]


async def _run_job(job_id: str, prompt: dict) -> None:
    job = JOBS[job_id]
    async with aiohttp.ClientSession() as session:
        try:
            pid = await _comfy_prompt(session, prompt)
            job["comfy_prompt_id"] = pid
            job["events"].append({"event": "workflow_start", "data": {}})
            files = []
            for _ in range(3600):
                await asyncio.sleep(2)
                async with session.get(f"{COMFY}/history/{pid}",
                                       timeout=aiohttp.ClientTimeout(total=30)) as r:
                    hist = (await r.json()).get(pid) or {}
                if not hist:
                    continue
                status = (hist.get("status") or {})
                if status.get("status_str") == "error":
                    msgs = status.get("messages") or []
                    raise RuntimeError(str(msgs)[:400])
                outs = hist.get("outputs") or {}
                for node in outs.values():
                    for img in (node.get("images") or []):
                        files.append({"filename": img.get("filename"),
                                      "subfolder": img.get("subfolder") or "",
                                      "type": img.get("type") or "output",
                                      "size": 0})
                if files:
                    break
            if not files:
                raise RuntimeError("нет результатов от ComfyUI")
            for f in files:
                path = os.path.join(OUT_DIR, f["subfolder"], f["filename"])
                try:
                    f["size"] = os.path.getsize(path)
                except OSError:
                    f["size"] = 0
            job["files"] = files
            job["status"] = "done"
            job["events"].append({"event": "workflow_done",
                                  "data": {"files": files, "count": len(files)}})
        except Exception as e:  # noqa: BLE001
            job["status"] = "error"
            job["error"] = str(e)[:500]
        finally:
            job["finished"] = time.time()


async def health(request: web.Request) -> web.Response:
    if not _auth(request):
        return _j({"error": "auth"}, 401)
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"{COMFY}/system_stats",
                             timeout=aiohttp.ClientTimeout(total=10)) as r:
                stats = await r.json()
    except Exception as e:  # noqa: BLE001
        return _j({"ok": False, "error": str(e)}, 200)
    devs = (stats.get("devices") or [{}])
    gpus = [{"index": i, "name": d.get("name", "GPU"),
             "mem_total": d.get("vram_total", 0) // (1024 * 1024),
             "mem_used": d.get("vram_total", 0) // (1024 * 1024) - d.get("vram_free", 0) // (1024 * 1024),
             "util": 0} for i, d in enumerate(devs)]
    return _j({"ok": True, "service": "vast-comfy-bridge", "version": "1.0",
               "uptime": int(time.time() - START_TS), "gpus": gpus,
               "workers": [{"index": 0, "ready": True, "busy": any(
                   j["status"] == "running" for j in JOBS.values()), "error": ""}],
               "queue": sum(1 for j in JOBS.values() if j["status"] == "queued"),
               "active": [{"id": k, "status": v["status"],
                           "elapsed": int((v.get("finished") or time.time()) - v["created"]),
                           "worker": 0} for k, v in JOBS.items()
                          if v["status"] in ("queued", "running")]})


async def submit(request: web.Request) -> web.Response:
    if not _auth(request):
        return _j({"error": "auth"}, 401)
    body = await request.json()
    prompt = body.get("prompt") or {}
    if not prompt:
        return _j({"error": "пустой prompt"}, 400)
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"id": job_id, "status": "running", "created": time.time(),
                    "finished": None, "files": [], "error": "", "events": []}
    asyncio.create_task(_run_job(job_id, prompt))
    return _j({"job_id": job_id})


async def job_status(request: web.Request) -> web.Response:
    if not _auth(request):
        return _j({"error": "auth"}, 401)
    jid = request.match_info["job_id"]
    job = JOBS.get(jid)
    if not job:
        return _j({"error": "нет job"}, 404)
    since = int(request.query.get("since", "0") or 0)
    events = job["events"][since:]
    return _j({"job": {"id": jid, "status": job["status"], "files": job["files"],
                       "error": job["error"]},
               "events": events, "cursor": len(job["events"])})


async def get_file(request: web.Request) -> web.StreamResponse:
    if not _auth(request):
        return _j({"error": "auth"}, 401)
    sub = request.query.get("subfolder", "")
    name = request.query.get("filename", "")
    path = os.path.join(OUT_DIR, sub, name)
    if not os.path.isfile(path):
        return _j({"error": "нет файла"}, 404)
    return web.FileResponse(path)


async def interrupt(request: web.Request) -> web.Response:
    try:
        async with aiohttp.ClientSession() as s:
            await s.post(f"{COMFY}/interrupt", timeout=aiohttp.ClientTimeout(total=10))
    except Exception:  # noqa: BLE001
        pass
    for j in JOBS.values():
        if j["status"] == "running":
            j["status"] = "error"
            j["error"] = "cancelled"
            j["finished"] = time.time()
    return _j({"status": "ok"})


async def shutdown(request: web.Request) -> web.Response:
    asyncio.get_running_loop().call_later(0.5, lambda: os._exit(0))
    return _j({"status": "ok"})


async def on_prepare(app: web.Application):
    pass


START_TS = time.time()


def main() -> None:
    app = web.Application()
    app.router.add_get("/health", health)
    app.router.add_post("/submit", submit)
    app.router.add_get("/job/{job_id}", job_status)
    app.router.add_get("/file", get_file)
    app.router.add_post("/interrupt", interrupt)
    app.router.add_post("/shutdown", shutdown)
    print(f"vast bridge on :{PORT}, comfy={COMFY}", flush=True)
    web.run_app(app, host="0.0.0.0", port=PORT, access_log=None)


if __name__ == "__main__":
    main()
