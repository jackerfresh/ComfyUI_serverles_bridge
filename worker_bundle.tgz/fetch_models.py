"""Скачивает модели из manifest.json в папки ComfyUI/models/<category>/."""

import json
import os
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

COMFY = "/workspace/comfy"
MODELS = os.path.join(COMFY, "models")


def _download(item: dict) -> str:
    cat = item.get("category") or "checkpoints"
    name = item.get("name") or ""
    url = item.get("url") or ""
    if not name or not url:
        return f"skip {name or '?'}: нет url"
    dest_dir = os.path.join(MODELS, cat)
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name)
    part = dest + ".part"
    if os.path.exists(dest) and os.path.getsize(dest) > 1024 * 1024:
        return f"ok {name}: уже есть"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "comfyui-bridge/1.0"})
        with urllib.request.urlopen(req, timeout=120) as r, open(part, "wb") as f:
            total = 0
            while True:
                chunk = r.read(8 * 1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                total += len(chunk)
        os.replace(part, dest)
        return f"ok {name}: {total // (1024 * 1024)} MB"
    except Exception as e:  # noqa: BLE001
        try:
            os.remove(part)
        except OSError:
            pass
        return f"ERR {name}: {e}"


def main() -> int:
    path = "/workspace/manifest.json"
    if not os.path.exists(path):
        print("нет manifest.json — пропускаю")
        return 0
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    items = data.get("models") or []
    if not items:
        print("манифест пуст")
        return 0
    print(f"моделей в манифесте: {len(items)}")
    with ThreadPoolExecutor(max_workers=6) as ex:
        futures = [ex.submit(_download, it) for it in items]
        for fut in as_completed(futures):
            print(fut.result())
    return 0


if __name__ == "__main__":
    sys.exit(main())
